import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PurchaseOrder } from '../types';
import {
  Truck,
  Plus,
  CheckCircle,
  Clock,
  Star,
  FileText,
  PackageCheck,
  Building,
  ArrowRight,
  X,
} from 'lucide-react';

export const PurchasingView: React.FC = () => {
  const { suppliers, purchaseOrders, receivePurchaseOrder } = useApp();

  const [activeTab, setActiveTab] = useState<'orders' | 'suppliers'>('orders');
  const [selectedPo, setSelectedPo] = useState<PurchaseOrder | null>(null);
  const [receivingMap, setReceivingMap] = useState<{ [prodId: string]: number }>({});
  const [isReceiveModalOpen, setIsReceiveModalOpen] = useState(false);

  const handleOpenReceive = (po: PurchaseOrder) => {
    setSelectedPo(po);
    const initialMap: { [prodId: string]: number } = {};
    po.items.forEach((item) => {
      initialMap[item.productId] = Math.max(0, item.orderQuantity - item.receivedQuantity);
    });
    setReceivingMap(initialMap);
    setIsReceiveModalOpen(true);
  };

  const handleConfirmReceive = () => {
    if (!selectedPo) return;
    receivePurchaseOrder(selectedPo.id, receivingMap);
    setIsReceiveModalOpen(false);
    setSelectedPo(null);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
            Purchases & Supplier Intelligence
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Automated procurement orders, goods receipt verification, and vendor delivery scorecard metrics.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-white text-slate-900 shadow-xs ring-1 ring-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4 text-slate-700" />
            <span>Purchase Orders ({purchaseOrders.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'suppliers'
                ? 'bg-white text-blue-700 shadow-xs ring-1 ring-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Truck className="w-4 h-4 text-blue-600" />
            <span>Supplier Scorecards ({suppliers.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: PURCHASE ORDERS */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">Purchase Orders Lifecycle</h3>
              <p className="text-xs text-slate-500">
                Track open supplier orders and verify shipments upon warehouse arrival.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase font-semibold text-[10px] tracking-wider">
                  <tr>
                    <th className="py-3 px-4">PO Number & Date</th>
                    <th className="py-3 px-3">Supplier Name</th>
                    <th className="py-3 px-3">Expected Date</th>
                    <th className="py-3 px-3">Line Items</th>
                    <th className="py-3 px-3">Total Amount</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {purchaseOrders.map((po) => {
                    const isReceived = po.status === 'received';
                    const isOrdered = po.status === 'ordered';

                    return (
                      <tr key={po.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900">{po.poNumber}</div>
                          <div className="text-[10px] text-slate-400 font-mono">Created: {po.createdAt}</div>
                        </td>
                        <td className="py-3.5 px-3 font-semibold text-slate-800">{po.supplierName}</td>
                        <td className="py-3.5 px-3 font-mono text-slate-600">{po.expectedDeliveryDate}</td>
                        <td className="py-3.5 px-3 text-slate-600">
                          {po.items.length} SKUs (
                          {po.items.reduce((a, b) => a + b.orderQuantity, 0)} units)
                        </td>
                        <td className="py-3.5 px-3 font-mono font-bold text-slate-900 text-sm">
                          ₹{po.totalAmount.toLocaleString('en-IN')}
                        </td>
                        <td className="py-3.5 px-3">
                          <span
                            className={`font-semibold text-[10px] px-2 py-0.5 rounded-full inline-flex items-center gap-1 ${
                              isReceived
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : isOrdered
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {isReceived && <CheckCircle className="w-3 h-3" />}
                            {isOrdered && <Clock className="w-3 h-3" />}
                            <span className="capitalize">{po.status.replace('_', ' ')}</span>
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          {isReceived ? (
                            <span className="text-[11px] text-emerald-600 font-semibold">
                              Received {po.receivedAt}
                            </span>
                          ) : (
                            <button
                              onClick={() => handleOpenReceive(po)}
                              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs shadow-2xs flex items-center gap-1 ml-auto cursor-pointer transition-colors"
                            >
                              <PackageCheck className="w-3.5 h-3.5" />
                              <span>Receive Goods</span>
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SUPPLIER SCORECARDS */}
      {activeTab === 'suppliers' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {suppliers.map((supplier) => (
              <div
                key={supplier.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-base font-bold text-slate-900">{supplier.name}</h4>
                      <div className="text-xs text-slate-500 mt-0.5 font-medium">
                        Contact: {supplier.contactPerson} · {supplier.phone}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        GSTIN: {supplier.gstin}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2 py-1 rounded-lg">
                      <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      <span className="text-xs font-bold font-mono text-amber-900">
                        {supplier.rating} / 5.0
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-100 text-center">
                    <div className="p-2 bg-slate-50 rounded-xl">
                      <div className="text-[10px] text-slate-500 font-medium">Avg Lead Time</div>
                      <div className="text-base font-extrabold font-mono text-slate-900 mt-0.5">
                        {supplier.averageDeliveryDays} Days
                      </div>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-xl">
                      <div className="text-[10px] text-slate-500 font-medium">On-Time Rate</div>
                      <div className="text-base font-extrabold font-mono text-emerald-600 mt-0.5">
                        {supplier.onTimeDeliveryRate}%
                      </div>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-xl">
                      <div className="text-[10px] text-slate-500 font-medium">Open Balance</div>
                      <div className="text-base font-extrabold font-mono text-slate-900 mt-0.5">
                        ₹{supplier.openBalance.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-400 text-[11px]">
                    Categories: {supplier.suppliedCategories.join(', ')}
                  </span>
                  <span className="font-bold text-blue-600">Active Vendor</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* GOODS RECEIVING MODAL */}
      {isReceiveModalOpen && selectedPo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Receive Goods for {selectedPo.poNumber}
                </h3>
                <span className="text-xs text-slate-500">Supplier: {selectedPo.supplierName}</span>
              </div>
              <button
                onClick={() => setIsReceiveModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Confirm the physical quantities delivered. Stock will be atomically added to your store's ledger.
            </p>

            <div className="space-y-3 max-h-72 overflow-y-auto">
              {selectedPo.items.map((line) => {
                const remaining = line.orderQuantity - line.receivedQuantity;
                const currentVal = receivingMap[line.productId] ?? remaining;

                return (
                  <div
                    key={line.productId}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-slate-900 truncate">{line.productName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Ordered: {line.orderQuantity} | Already Received: {line.receivedQuantity}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="text-[11px] text-slate-500 font-medium">Receiving Now:</label>
                      <input
                        type="number"
                        min="0"
                        max={remaining}
                        value={currentVal}
                        onChange={(e) =>
                          setReceivingMap((prev) => ({
                            ...prev,
                            [line.productId]: parseInt(e.target.value) || 0,
                          }))
                        }
                        className="w-16 px-2 py-1 text-center font-mono font-bold bg-white border border-slate-300 rounded-lg text-slate-900"
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setIsReceiveModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReceive}
                className="px-5 py-2 bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] hover:from-[#1D4ED8] hover:to-[#1E40AF] text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Confirm & Update Inventory</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
